package com.example.register;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private LinearLayout statsContainer;
    private LinearLayout shortcutsContainer;
    private LinearLayout transactionsContainer;
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        statsContainer = findViewById(R.id.statsContainer);
        shortcutsContainer = findViewById(R.id.shortcutsContainer);
        transactionsContainer = findViewById(R.id.transactionsContainer);
        bottomNav = findViewById(R.id.bottomNav);

        String username = getIntent().getStringExtra("username");

        tampilkanHeaderUsername(username);
        tampilkanStatistik();
        tampilkanQuickActions();
        tampilkanAktivitas();

        // Bottom navigation belum diberi aksi.
        // Nanti bisa ditambahkan setelah login sudah berjalan.
    }

    private void tampilkanHeaderUsername(String username) {

        // Saat ini header XML masih menggunakan tulisan:
        // "Welcome back!"
        //
        // Username dari LoginActivity tetap diterima melalui Intent.
        // Kalau nanti mau menampilkan username di dashboard,
        // kita bisa tambahkan TextView khusus untuk username.
    }

    private void tampilkanStatistik() {

        statsContainer.removeAllViews();

        buatStatistik(
                "Income",
                "$8,450",
                statsContainer
        );

        buatStatistik(
                "Expense",
                "$3,250",
                statsContainer
        );

        buatStatistik(
                "Savings",
                "$5,200",
                statsContainer
        );
    }

    private void buatStatistik(
            String judul,
            String nilai,
            LinearLayout parent
    ) {

        LinearLayout box = new LinearLayout(this);

        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 20, 20, 20);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        params.setMargins(5, 5, 5, 5);

        box.setLayoutParams(params);

        TextView title = new TextView(this);

        title.setText(judul);
        title.setTextSize(12);

        // UBAH MENJADI HITAM
        title.setTextColor(Color.BLACK);

        TextView value = new TextView(this);

        value.setText(nilai);
        value.setTextSize(18);

        // UBAH MENJADI HITAM
        value.setTextColor(Color.BLACK);

        value.setGravity(Gravity.CENTER_VERTICAL);

        box.addView(title);
        box.addView(value);

        parent.addView(box);
    }

    private void tampilkanQuickActions() {

        shortcutsContainer.removeAllViews();

        buatAction("Tambah Transaksi");
        buatAction("Lihat Saldo");
        buatAction("Riwayat Transaksi");
    }

    private void buatAction(String text) {

        TextView action = new TextView(this);

        action.setText(text);
        action.setTextSize(15);

        // UBAH MENJADI HITAM
        action.setTextColor(Color.BLACK);

        action.setGravity(Gravity.CENTER_VERTICAL);

        action.setPadding(20, 25, 20, 25);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(0, 5, 0, 5);

        action.setLayoutParams(params);

        action.setOnClickListener(v -> {

            // Aksi bisa ditambahkan nanti.

        });

        shortcutsContainer.addView(action);
    }

    private void tampilkanAktivitas() {

        transactionsContainer.removeAllViews();

        buatTransaksi(
                "Pembelian",
                "- $120.00"
        );

        buatTransaksi(
                "Gaji",
                "+ $2,500.00"
        );

        buatTransaksi(
                "Makan",
                "- $25.00"
        );
    }

    private void buatTransaksi(
            String nama,
            String nominal
    ) {

        LinearLayout row = new LinearLayout(this);

        row.setOrientation(
                LinearLayout.HORIZONTAL
        );

        row.setGravity(
                Gravity.CENTER_VERTICAL
        );

        row.setPadding(
                10,
                15,
                10,
                15
        );

        LinearLayout.LayoutParams rowParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        row.setLayoutParams(rowParams);

        TextView namaText = new TextView(this);

        namaText.setText(nama);
        namaText.setTextSize(15);

        // UBAH MENJADI HITAM
        namaText.setTextColor(Color.BLACK);

        LinearLayout.LayoutParams namaParams =
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1
                );

        namaText.setLayoutParams(namaParams);

        TextView nominalText = new TextView(this);

        nominalText.setText(nominal);
        nominalText.setTextSize(14);

        // UBAH MENJADI HITAM
        nominalText.setTextColor(Color.BLACK);

        row.addView(namaText);
        row.addView(nominalText);

        transactionsContainer.addView(row);
    }
}