package com.example.register;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class RegisterActivity extends AppCompatActivity {

    private static final String URL_REGISTER =
            "https://ahanbilly.cu.ma/login_app/register.php";

    EditText etUsername;
    EditText etEmail;
    EditText etPassword;
    EditText etKonfirmasi;

    Button btnRegister;

    ProgressBar progressBar;

    TextView tvLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);

        etUsername =
                findViewById(R.id.etUsername);

        etEmail =
                findViewById(R.id.etEmail);

        etPassword =
                findViewById(R.id.etPassword);

        etKonfirmasi =
                findViewById(R.id.etKonfirmasi);

        btnRegister =
                findViewById(R.id.btnRegister);

        progressBar =
                findViewById(R.id.progressBar);

        tvLogin =
                findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(
                v -> registerUser()
        );

        tvLogin.setOnClickListener(v ->
                finish()
        );
    }

    private void registerUser() {

        final String username =
                etUsername.getText()
                        .toString()
                        .trim();

        final String email =
                etEmail.getText()
                        .toString()
                        .trim();

        final String password =
                etPassword.getText()
                        .toString()
                        .trim();

        final String konfirmasi =
                etKonfirmasi.getText()
                        .toString()
                        .trim();

        if (username.isEmpty()
                || email.isEmpty()
                || password.isEmpty()
                || konfirmasi.isEmpty()) {

            Toast.makeText(
                    this,
                    "Semua field wajib diisi!",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        if (username.length() < 4) {

            etUsername.setError(
                    "Username minimal 4 karakter"
            );

            etUsername.requestFocus();

            return;
        }

        if (!isValidEmail(email)) {

            etEmail.setError(
                    "Format email tidak valid"
            );

            etEmail.requestFocus();

            return;
        }

        if (password.length() < 6) {

            etPassword.setError(
                    "Password minimal 6 karakter"
            );

            etPassword.requestFocus();

            return;
        }

        if (!password.equals(konfirmasi)) {

            etKonfirmasi.setError(
                    "Password tidak cocok"
            );

            etKonfirmasi.requestFocus();

            return;
        }

        progressBar.setVisibility(
                View.VISIBLE
        );

        btnRegister.setEnabled(false);

        StringRequest request =
                new StringRequest(
                        Request.Method.POST,
                        URL_REGISTER,

                        response -> {

                            progressBar.setVisibility(
                                    View.GONE
                            );

                            btnRegister.setEnabled(true);

                            try {

                                JSONObject json =
                                        new JSONObject(response);

                                boolean success =
                                        json.getBoolean(
                                                "success"
                                        );

                                String message =
                                        json.getString(
                                                "message"
                                        );

                                Toast.makeText(
                                        this,
                                        message,
                                        Toast.LENGTH_LONG
                                ).show();

                                if (success) {

                                    etUsername.setText("");
                                    etEmail.setText("");
                                    etPassword.setText("");
                                    etKonfirmasi.setText("");

                                    btnRegister.postDelayed(
                                            this::finish,
                                            1000
                                    );
                                }

                            } catch (Exception e) {

                                Toast.makeText(
                                        this,
                                        "Error parsing: "
                                                + e.getMessage(),
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        },

                        error -> {

                            progressBar.setVisibility(
                                    View.GONE
                            );

                            btnRegister.setEnabled(true);

                            Toast.makeText(
                                    this,
                                    "Koneksi gagal: "
                                            + error.getMessage(),
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                ) {

                    @Override
                    protected Map<String, String>
                    getParams() {

                        Map<String, String> params =
                                new HashMap<>();

                        params.put(
                                "username",
                                username
                        );

                        params.put(
                                "email",
                                email
                        );

                        params.put(
                                "password",
                                password
                        );

                        return params;
                    }
                };

        Volley
                .newRequestQueue(this)
                .add(request);
    }

    private boolean isValidEmail(
            String email
    ) {

        String regex =
                "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        return Pattern
                .compile(regex)
                .matcher(email)
                .matches();
    }
}